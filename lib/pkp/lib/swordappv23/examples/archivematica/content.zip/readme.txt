This is a test zip file for demonstrating Archivematic to DSpace integration using SWORDv2.

This is the DIP.
